function addToQueue(songId) {
  fetch('https://spotty-melons-own-24-142-147-68.loca.lt/queue', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ songId })
  })
  .then(response => {
    // Handle the response from the server
  })
  .catch(error => {
    // Handle any errors that occur
  });
}

const firebaseConfig = {
  // Your Firebase project configuration goes here
};
const firebaseConfig = {
  apiKey: "AIzaSyAeb0l-s7JELlZL_R4hkHW2_lBuHmKW2hw",
  authDomain: "baiters-spotify.firebaseapp.com",
  projectId: "baiters-spotify",
  storageBucket: "baiters-spotify.appspot.com",
  messagingSenderId: "668268635031",
  appId: "1:668268635031:web:2605d42fad2d3d46509ad2",
  measurementId: "G-LY0P3N3G87"
};

firebase.initializeApp(668268635031);

const database = firebase.database();

document.getElementById("add-song-button").addEventListener("click", () => {
  const songName = document.getElementById("song-name").value;
  const newSongRef = database.ref("queue").push();
  newSongRef.set({
    name: songName
  })
    .then(() => {
      console.log("Song added to queue:", songName);
    })
    .catch((error) => {
      console.error("Error adding song to queue:", error);
    });
});

